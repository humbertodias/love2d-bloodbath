BloodBath
=========

A simple beat-em-up game featuring EngD students at Bath university

To run it, you need to install the Love2D runtime from [love2d.org](http://love2d.org).
Once installed, double click bloodbath.love, or type "love ." inside the project directory.

Controls:
Player 1: W = jump, A = left, S = crouch, D = right, left shift = punch, left control = kick
Player 2: Up arrow = jump, Left arrow = left, Down arrow = crouch, Right arrow = right, Return = punch, Right shift = kick

Press escape to exit the game at any time.
